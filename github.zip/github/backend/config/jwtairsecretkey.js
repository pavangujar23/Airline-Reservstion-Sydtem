
module.exports={
    remoteDbUrl :"mongodb://localhost:27017/technoairlines",
    jwtsecretkey :'we are technocrats'
}