const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const FlightSchema = new Schema({
    flightimg : {
        type : String
    },
    flightname : {
        type : String,
        required:true      
    },
    from : {
        type : String,
        required: true
    },  
    to : {
        type : String
    },
    departuredate : {
        type: String,
        required: true
    },
    status : {
        type: String,
        required: true
    },
    date : {
        type: Date,
        default: Date.now
    }
   
   
})


module.exports = mongoose.model('flightinfo', FlightSchema);
