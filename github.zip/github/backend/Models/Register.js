const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const Register = new Schema({
    username : {
        type: String,
    },
    email : {
        type: String,
        required: true,
        unique: true
    },
    phonenumber:{ 
        type: Number,
        required: true

    },
    password : {
        type: String,
        required: true
    },
    date : {
        type: Date,
        default: Date.now
    }
})

module.exports = mongoose.model('register', Register);