const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const AirlineBookingSchema = new Schema({
    from : {
        type : String,
        required : true
    },
    to : {
        type : String,
        required : true,
        
    },
    arrival : {
        type : String,
        required : true
    },
    departure : {
        type : String,
        required : true
    },
    class : {
        type: String,
        required: true
    },
    // adult: {
    //     type : Number,
    //     required :true
    // },
    // child : {
    //     type : Number,
    // },
    // infant : {
    //     type : Number
    // },
    date: {
        type: Date,
        default: Date.now
    }
})


module.exports = mongoose.model('airlinebooking',AirlineBookingSchema);
