const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const cors = require('cors');
const cookieParser = require('cookie-parser');
const app =express();

const UsersRoute = require('./routes/register');
const AdminRoute = require('./routes/adminregister');
const BookingRoute = require('./routes/bookuser');
const ContactRoute = require('./routes/contactus');
const FlightInfoRoute = require('./routes/flightinfo')

const config = require('./config/jwtairsecretkey');

mongoose.connect(config.remoteDbUrl ,
    {useNewUrlParser: true} , (err)=>{
        if(err) throw err;
        console.log(`database connected`);
    });

    //body parser middleware.........
    app.use(bodyParser.urlencoded({extended:true}));
    app.use(bodyParser.json());


    ///cookie parser....
    app.use(cookieParser());

    
    ///cors parser....
    app.use(cors());

    app.use('/airlines' , UsersRoute);
    app.use('/admin', AdminRoute);
    app.use('/booking', BookingRoute);
    app.use('/contact', ContactRoute);
    app.use('/flightinfo' , FlightInfoRoute);

    const port = process.env.PORT || 3000;
    app.listen(port , (err) =>{
        if(err) throw err;
        console.log('App listening on port 3000!');
    });