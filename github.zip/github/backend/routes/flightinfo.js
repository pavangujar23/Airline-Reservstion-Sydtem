const express = require('express'); 
const mongoose = require('mongoose');
const bcrypt=require('bcryptjs');


//extra middleware required.....
const HttpStatus = require('http-status-codes');
const Joi = require('joi');
const jwt = require('jsonwebtoken');
const config = require('../config/jwtairsecretkey');

require('../Models/FlightInfo');
const FlightInfo = mongoose.model('flightinfo');


const router = express.Router();

//GET METHOD
router.get('/flight' , (req , res)=>{
    FlightInfo.find({}).then(flight =>{
        res.status(HttpStatus.OK).json(flight)
    }).catch(err => console.log(err))
})

//POST METHOD
// router.post('/post' , (req ,res) =>{
//     const schema = Joi.object().keys({
//         flightname: Joi.string().required(),
//         from: Joi.string().required(),
//         to: Joi.string().required(),
//         access_token: [Joi.string(), Joi.number()],      
//         departuredate: Joi.string().required(),
//         status: Joi.string().required()
        
//     });
//     const{ error, value} = Joi.validate(req.body, schema);
//     if(error && error.details) {
//         return res.status(HttpStatus.BAD_REQUEST).json({msg : error.message})
//     }

    // const NewUser = new FlightInfo({
    //     flightname: req.body.flightname,
    //     from : req.body.from,
    //     to : req.body.to,       
    //     departuredate :req.body.departuredate,
    //     status: req.body.status
       
    // });
    // NewUser.save().then(user =>{
    //     const token = jwt.sign({data:user} , config.jwtsecretkey ,{
    //         expiresIn :'1h'
    //     });
    //     res.cookie('auth' ,token);
    //     res.status(201).json({message:'successfully registered into database'
    //    ,user , token}); 
    // });


    router.post('/', (req, res) => {
        const NewUser = new FlightInfo({
            flightimg : req.body.flightimg,
            flightname: req.body.flightname,
            from : req.body.from,
            to : req.body.to,       
            departuredate :req.body.departuredate,
            status: req.body.status
        });
         NewUser.save().then(user =>{
            const token = jwt.sign({data:user} , config.jwtsecretkey ,{
                expiresIn :'1h'
            });
            res.cookie('auth' ,token);
            res.status(201).json({message:'successfully registered into database'
            , user , token}); 
        });
        // NewUser.save((err, doc) => {
        //     if (!err) { res.send(doc); }
        //     else { console.log('Error in Employee Save :' + JSON.stringify(err, undefined, 2)); }
        // });
    });

  

    //Update method
    router.put('/:id', (req, res) => {
    if (!ObjectId.isValid(req.params.id))
        return res.status(400).send(`No record with given id : ${req.params.id}`);

    var flt = {
        flightimg : req.body.flightimg,
        flightname: req.body.flightname,
        from : req.body.from,
        to : req.body.to,       
        departuredate :req.body.departuredate,
        status: req.body.status
    };
    FlightInfo.findByIdAndUpdate(req.params.id, { $set: flt }, { new: true }, (err, doc) => {
        if (!err) { res.send(doc); }
        else { console.log('Error in Employee Update :' + JSON.stringify(err, undefined, 2)); }
    });
});

    
//delete method

router.delete('/:id', (req, res) => {
    if (!ObjectId.isValid(req.params.id))
        return res.status(400).send(`No record with given id : ${req.params.id}`);

        FlightInfo.findByIdAndRemove(req.params.id, (err, doc) => {
        if (!err) { res.send(doc); }
        else { console.log('Error in Employee Delete :' + JSON.stringify(err, undefined, 2)); }
    });

});


    






module.exports = router;


                
            
        





