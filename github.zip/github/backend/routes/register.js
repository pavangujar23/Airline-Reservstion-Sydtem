const express = require('express');
const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

//extra middleware requirred...
const HttpStatus = require('http-status-codes');
const joi = require('joi');
const jwt = require('jsonwebtoken');
const config =require('../config/jwtairsecretkey');

require('../Models/Register');
const RegisterUser = mongoose.model('register')


const router = express.Router();


router.post('/register', (req,res)=>{
    const schema = joi.object().keys({
        username:joi.string().alphanum().min(3).max(30).required(),
        email:joi.string().email().required(),
        phonenumber: joi.string().required(),
        password:joi.string().regex(/^[a-zA-Z0-9]{3,30}$/),
        access_token:[joi.string(),joi.number()]
        
    });
    const { error, value } = joi.validate(req.body, schema);
    if(error && error.details){
        return res.status(HttpStatus.BAD_REQUEST).json({msg:error.message})
    }


    RegisterUser.findOne({email:req.body.email}).then(user =>{
        if(user){
            return res.status(HttpStatus.CONFLICT)
            .json({message : 'Email is already taken'})
        } else {
             const NewUser = new RegisterUser({
                 username : req.body.username,
                 phonenumber: req.body.phonenumber,
                 email : req.body.email,
                 password : req.body.password
             });
             bcrypt.genSalt(10 , (err , salt)=>{
                 bcrypt.hash(NewUser.password, salt, (err, hash)=>{
                     if(err) throw err;
                     NewUser.password = hash;
                     NewUser.save().then(user =>{
                         const token = jwt.sign({data:user} , config.jwtsecretkey ,{
                             expiresIn :'1h'
                         });
                         res.cookie('auth' ,token);
                         res.status(201).json({message:'successfully registered into database'
                        ,user , token});
                     })
                 });
             });
        }
    }).catch(err => console.log(err));
});

router.post('/login', (req,res)=>{
    if(!req.body.email || !req.body.password){
            return res.status(HttpStatus.INTERNAL_SERVER_ERROR).json({message:'no empty fieldssssss'})
    }
    RegisterUser.findOne({email:req.body.email}
        ).then(user =>{
        if(!user){
            return res.status(HttpStatus.NOT_FOUND)
            .json({message : 'No user found'})
        }
        return bcrypt.compare(req.body.password,user.password).then(result =>{
            if(!result){
                return res.status(HttpStatus.INTERNAL_SERVER_ERROR)
            .json({message : 'password wrong'})
            }
            const token = jwt.sign({data:user} , config.jwtsecretkey ,{
                expiresIn :'1h'
            });
            res.cookie('auth' ,token);
            res.status(201).json({message:'successfully logged in'
           ,user , token});
        })
    });
});

//GET METHOD 
router.get('/', (req, res)=> {
    RegisterUser.find({}, (err, result) => {
        if (err) throw err;
        console.log(result);
        res.json(result);

    })
    

})
//put method........

router.put('/:id', (req,res)=> {
    if(!ObjectId.inValid(req.params.id))
    return res.status(400).send(`No Userss with this UserId :${req.params.id}`)



    const user = {
        username: req.body.username,
        email: req.body.email,
        phonenumber: req.body.phonenumber,
        password: req.body.password
    };
    
    RegisterUser.findByIdAndUpdate(req.params.id, {$set: user}, {new: true}, (err , data)=> {
        if (!err) {res.send(doc);}
        else {
             console.log('Error in User Update :' + JSON.stringify(err, undefined, 2)); 
        }
    });
})




//delete method

router.delete('/:id', (req, res) => {
    if (!ObjectId.isValid(req.params.id))
        return res.status(400).send(`No user with given id : ${req.params.id}`);

        RegisterUser.findByIdAndRemove(req.params.id, (err, doc) => {
        if (!err) { res.send(doc); }
        else { console.log('Error in User Delete :' + JSON.stringify(err, undefined, 2)); }
    });
});







module.exports = router;