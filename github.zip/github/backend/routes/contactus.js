const express = require('express');
const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

//extra middleware requirred...
const HttpStatus = require('http-status-codes');
const joi = require('joi');
const jwt = require('jsonwebtoken');
const config =require('../config/jwtairsecretkey');

require('../Models/ContactUs');
const AdminRegister = mongoose.model('contactus')

const router = express.Router();
router.post('/contactus' , (req ,res) =>{
    const schema = joi.object().keys({
        name: joi.string().required(),
        email: joi.string().required(),
        access_token: [joi.string(), joi.number()],
        subject: joi.string().required(),
        phonenumber: joi.number().required(),
        message: joi.string().required()
        
    });
    const{ error, value} = joi.validate(req.body, schema);
    if(error && error.details) {
        return res.status(HttpStatus.BAD_REQUEST).json({msg : error.message})
    }

    const NewUser = new AdminRegister({
       name: req.body.name,
       email: req.body.email,
       subject: req.body.subject,
       phonenumber: req.body.phonenumber,
       message: req.body.message
    });
    NewUser.save().then(user =>{
        const token = jwt.sign({data:user} , config.jwtsecretkey ,{
            expiresIn :'1h'
        });
        res.cookie('auth' ,token);
        res.status(201).json({message:'successfully registered into database'
       ,user , token}); 
    });

});



module.exports = router;
