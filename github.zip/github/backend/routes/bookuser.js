const express = require('express'); 
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const bcrypt=require('bcryptjs');

//extra middleware required.....
const HttpStatus = require('http-status-code');
const Joi = require('joi');
const jwt = require('jsonwebtoken');
const config = require('../config/jwtairsecretkey');

require('../Models/Booking');
const AirlineBooking =mongoose.model('airlinebooking');


const router = express.Router();

router.post('/booking' , (req ,res) =>{
    const schema = Joi.object().keys({
        from: Joi.string().alphanum().required(),
        to: Joi.string().alphanum().required(),
        access_token: [Joi.string(), Joi.number()],
        arrival: Joi.string().required(),
        departure: Joi.string().required(),
        class: Joi.string().required()
        
    });
    const{ error, value} = Joi.validate(req.body, schema);
    if(error && error.details) {
        return res.status(HttpStatus.BAD_REQUEST).json({msg : error.message})
    }

    const NewUser = new AirlineBooking({
        from : req.body.from,
        to : req.body.to,
        arrival :req.body.arrival,
        departure :req.body.departure,
        class: req.body.class,
        adults: req.body.adults,
        child: req.body.child,
        infant:req.body.infant
    });
    NewUser.save().then(user =>{
        const token = jwt.sign({data:user} , config.jwtsecretkey ,{
            expiresIn :'1h'
        });
        res.cookie('auth' ,token);
        res.status(201).json({message:'successfully registered into database'
       ,user , token}); 
    });

});



module.exports = router;


                
            
        








    
// //post create method here 
// router.post ('/booking' , (req,res)=>{
  
//     if(errors.length>0){
//         res.render('/booking',{
//             errors,
//             from : req.body.from,
//             to : req.body.to,
//             arrival :req.body.arrival,
//             departure :req.body.departure,
//             class: req.body.class,
//             adults: req.body.adults,
//             child:req.body.child,
//             infant:req.body.infant
//         })
//         }else{
//         const NewPost = {
//             from : req.body.from,
//             to : req.body.to,
//             arrival :req.body.arrival,
//             departure :req.body.departure,
//             class: req.body.class,
//             adults: req.body.adults,
//             child:req.body.child,
//             infant:req.body.infant
//         }
//         new Booking(NewPost).save().then(post =>{
//             req.flash('success_msg','successfully booked');
//             res.redirect('/booking');
//         })
//     }
// })


