const express = require('express');
const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

//extra middleware requirred...
const HttpStatus = require('http-status-codes');
const joi = require('joi');
const jwt = require('jsonwebtoken');
const config =require('../config/jwtairsecretkey');

require('../Models/AdminRegister');
const AdminRegister = mongoose.model('adminRegister')

const router = express.Router();


router.post('/adminregister', (req,res)=>{
    const schema = joi.object().keys({
        username:joi.string().alphanum().min(3).max(30).required(),
        email:joi.string().email().required(),
        
        password:joi.string().regex(/^[a-zA-Z0-9]{3,30}$/),
        access_token:[joi.string(),joi.number()]
        
    });
    const { error, value } = joi.validate(req.body, schema);
    if(error && error.details){
        return res.status(HttpStatus.BAD_REQUEST).json({msg:error.message})
    }


    AdminRegister.findOne({email:req.body.email}).then(user =>{
        if(user){
            return res.status(HttpStatus.CONFLICT)
            .json({message : 'Email is already taken'})
        } else {
             const NewUser = new AdminRegister({
                 username : req.body.username,
                 
                 email : req.body.email,
                 password : req.body.password
             });
             bcrypt.genSalt(10 , (err , salt)=>{
                 bcrypt.hash(NewUser.password, salt, (err, hash)=>{
                     if(err) throw err;
                     NewUser.password = hash;
                     NewUser.save().then(user =>{
                         const token = jwt.sign({data:user} , config.jwtsecretkey ,{
                             expiresIn :'1h'
                         });
                         res.cookie('auth' ,token);
                         res.status(201).json({message:'successfully registered into database'
                        ,user , token});
                     })
                 });
             });
        }
    }).catch(err => console.log(err));
});

router.post('/adminlogin', (req,res)=>{
    if(!req.body.email || !req.body.password){
            return res.status(HttpStatus.INTERNAL_SERVER_ERROR).json({message:'no empty fieldssssss'})
    }
    AdminRegister.findOne({email:req.body.email} 
        ).then(user =>{
        if(!user){
            return res.status(HttpStatus.NOT_FOUND)
            .json({message : 'No user found'})
        }
        return bcrypt.compare(req.body.password, user.password).then(result =>{
            if(!result){
                return res.status(HttpStatus.INTERNAL_SERVER_ERROR)
            .json({message : 'password wrong'})
            }
            const token = jwt.sign({data:user} , config.jwtsecretkey ,{
                expiresIn :'1h'
            });
            res.cookie('auth' ,token);
            res.status(201).json({message:'successfully logged in'
           ,user , token});
        })
    });
});





module.exports = router;