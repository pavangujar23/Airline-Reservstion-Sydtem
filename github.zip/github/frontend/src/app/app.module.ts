
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';



import { HttpClientModule} from '@angular/common/http'
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AirHomeComponent } from './air-home/air-home.component';
import { AirHeaderComponent } from './air-header/air-header.component';
import { AirLoginComponent } from './air-login/air-login.component';
import { AirAboutUsComponent } from './air-about-us/air-about-us.component';
import { AirContactUsComponent } from './air-contact-us/air-contact-us.component';
import { AirOffersComponent } from './air-offers/air-offers.component';
import { AirFooterComponent } from './air-footer/air-footer.component';
import { AirPageNotFoundComponent } from './air-page-not-found/air-page-not-found.component';

import { CookieService } from 'ngx-cookie-service';
import { AirregisterComponent } from './airregister/airregister.component';
import { from } from 'rxjs';
import { AdminloginComponent } from './adminlogin/adminlogin.component';
import { AdminregisterComponent } from './adminregister/adminregister.component';
import { UpdateRegisterComponent } from './update-register/update-register.component';
import { AirsafetyComponent } from './airsafety/airsafety.component';
import { FlightupdateComponent } from './flightupdate/flightupdate.component';
import { BookingComponent } from './booking/booking.component';




@NgModule({
  declarations: [
    AppComponent,
    AirHomeComponent,
    AirHeaderComponent,
    AirLoginComponent,
    AirAboutUsComponent,
    AirContactUsComponent,
    AirOffersComponent,
    AirFooterComponent,
    AirPageNotFoundComponent,
    AirregisterComponent,
    AdminloginComponent,
    AdminregisterComponent,
    UpdateRegisterComponent,
    AirsafetyComponent,
    FlightupdateComponent,
    BookingComponent
    
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule
  ],
  providers: [CookieService],
  bootstrap: [AppComponent]
})
export class AppModule { }
