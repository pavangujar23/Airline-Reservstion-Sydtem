import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { TokenService } from './token.service';
import { UpdateUser } from './updateUsers.model';
import { Router } from '@angular/router';



@Injectable({
  providedIn: 'root'
})
export class AuthService {
  router: Router;
  updatemodel : UpdateUser;
  usermodels: UpdateUser[];
  baseUrl = "http://localhost:3000";
  constructor(private http : HttpClient, private tokenService : TokenService,
    router: Router) { }

  //CRUD OPERATIONSSSSS.........

  registerUser(body) : Observable<any> {
    return this.http.post<any>(`${this.baseUrl}/airlines/register`, body)
  }

  getUser() : Observable<any> {
    return this.http.get<any>(`${this.baseUrl}/airlines`);
  }
  editUser(body) : Observable<any> {
    return this.http.put<any>(`${this.baseUrl}`+`/${body._id}`,body)
 }

 deleteUser(body) : Observable<any> {
   return this.http.delete<any>(`${this.baseUrl}`+ `${body._id}`, body)
 }

  loginUser(body):Observable<any> {
    console.log(body)
    return this.http.post(`${this.baseUrl}/airlines/login`, body)
  }


  bookingUser(body):Observable<any> {
    return this.http.post(`${this.baseUrl}/airlines/booking`, body);
  }

 

  isLoggedIn() {
    if (this.tokenService.GetToken()){
      return true;

    }
    return false;

  };

  logout() {
    this.tokenService.DeleteToken();
    this.router.navigate(['/login']);
    
  }
}
