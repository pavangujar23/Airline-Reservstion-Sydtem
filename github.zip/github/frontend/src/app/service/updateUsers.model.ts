export class UpdateUser {
    _id: String;
    username: String;
    email: String;
    phonenumber: String;

};