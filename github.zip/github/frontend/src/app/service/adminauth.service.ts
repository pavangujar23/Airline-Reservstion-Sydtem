import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { TokenService } from './token.service';
import { Observable } from 'rxjs';
import { Router } from '@angular/router';


@Injectable({
  providedIn: 'root'
})
export class AdminauthService {
  router = Router;
  
  baseUrl = "http://localhost:3000";

  
  constructor(private http : HttpClient, private tokenService : TokenService) { }

  registerUser(body) : Observable<any> {
    return this.http.post(`${this.baseUrl}/airlines/adminregister`, body)
  }

  loginUser(body):Observable<any> {
    return this.http.post(`${this.baseUrl}/airlines/adminlogin`, body)
  }

  contactUser(body):Observable<any> {
    return this.http.post(`${this.baseUrl}/airlines/contactus`,body)
  }

 

  isLoggedIn() {
    if (this.tokenService.GetToken()){
      return true;

    }
    return false;

  };
}

