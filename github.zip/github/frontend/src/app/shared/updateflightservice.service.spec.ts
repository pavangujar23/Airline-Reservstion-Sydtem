import { TestBed } from '@angular/core/testing';

import { UpdateflightserviceService } from './updateflightservice.service';

describe('UpdateflightserviceService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: UpdateflightserviceService = TestBed.get(UpdateflightserviceService);
    expect(service).toBeTruthy();
  });
});
