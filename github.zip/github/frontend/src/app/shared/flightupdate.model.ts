export class FlightUpdateDetails {
    _id: string;
    flightimg :string;
    flightname: string;
    from: string;
    to: string;
    departuredate: string;
    status: string
}
