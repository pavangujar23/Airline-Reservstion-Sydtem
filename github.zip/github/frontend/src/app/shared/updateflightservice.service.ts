import { FlightupdateComponent } from './../flightupdate/flightupdate.component';
import { Injectable } from '@angular/core';
// import 'rxjs/add/operator/map';
// import 'rxjs/add/operator/toPromise';
import { HttpClient } from '@angular/common/http';
import { FlightUpdateDetails } from './flightupdate.model'

@Injectable({
  providedIn: 'root'
})
export class UpdateflightserviceService {

  selectedFlights: FlightUpdateDetails;
  flights: FlightUpdateDetails[];
  readonly baseURL = 'http://localhost:3000/flightinfo';


  constructor(private http: HttpClient) { }

  postFlightDetails(flt: FlightUpdateDetails) {
    return this.http.post(this.baseURL, flt);
  }

  getFlightDetails() {
    return this.http.get(`${this.baseURL}/flight`);
  }

  putFlightDetails(flt: FlightUpdateDetails) {
    return this.http.put(this.baseURL + `/${flt._id}`, flt);
  }

  deleteFlightDetails(_id: string) {
    return this.http.delete(this.baseURL + `/${_id}`);
  }
}
