import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AirAboutUsComponent } from './air-about-us.component';

describe('AirAboutUsComponent', () => {
  let component: AirAboutUsComponent;
  let fixture: ComponentFixture<AirAboutUsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AirAboutUsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AirAboutUsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
