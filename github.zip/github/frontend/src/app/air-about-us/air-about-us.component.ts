import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-air-about-us',
  templateUrl: './air-about-us.component.html',
  styleUrls: ['./air-about-us.component.css']
})
export class AirAboutUsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
