import { UpdateflightserviceService } from './../shared/updateflightservice.service';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-booking',
  templateUrl: './booking.component.html',
  styleUrls: ['./booking.component.css']
})

export class BookingComponent implements OnInit {
  
  UpdateflightserviceService: any[] = [];
   flights:any= [];
  
  constructor(private service:UpdateflightserviceService, private router: Router) { 
    // this.service.getFlightDetails().subscribe(data=> {
    //   console.log(data)
    //   this.flights = data;
    // })
  }

  ngOnInit() {
    this.getData()
  }
  
  onClick() {
    this.router.navigate(['']);
  }

  getData() {
    // window.fetch(`http://localhost:3000/flightinfo/flight`).then(data =>{
    //   data.json().then(res =>{
    //     console.log(res)
    //     this.UpdateflightserviceService = res;
    //   }).catch(err => console.log(err))
    // })

    this.service.getFlightDetails().subscribe(data =>{
      console.log(data);
      this.flights = data;
    })

  }
}
