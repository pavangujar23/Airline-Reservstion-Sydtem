import { Component, OnInit } from '@angular/core';
import { Validators, FormGroup, FormBuilder } from '@angular/forms';

import { Router } from '@angular/router';
import { AdminauthService } from '../service/adminauth.service';

@Component({
  selector: 'app-adminregister',
  templateUrl: './adminregister.component.html',
  styleUrls: ['./adminregister.component.css']
})
export class AdminregisterComponent implements OnInit {

  errorMessage: string;
  adminregisterForm: FormGroup;
  constructor(
    private service: AdminauthService,
    private fb: FormBuilder,
    private router: Router
  ) { }

  ngOnInit() {
    this.init();
  }


  get username() {
    return this.adminregisterForm.get('username');
  }
  get email() {
    return this.adminregisterForm.get('email');
  }
 
  get password() {
    return this.adminregisterForm.get('password');
  }

  init() {
    this.adminregisterForm = this.fb.group({
      username: ["", Validators.required],
      email: ["", [Validators.required, Validators.email]],
      password: ["", Validators.required]
    });
  }
  
  login() {
    this.router.navigate(['/adminlogin']);
  }

  onSubmit() {
    this.service.registerUser(this.adminregisterForm.value).subscribe( user=> {
      this.adminregisterForm.reset();
      this.router.navigate(['/adminlogin']);
    },
   (err)=> {
    if (err.error.msg) {
      this.errorMessage = err.error.msg[0].message;

    }
    if(err.error.message) {
      this.errorMessage = err.error.message;    
    }
  })

};

}
