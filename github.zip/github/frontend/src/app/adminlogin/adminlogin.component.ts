import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { TokenService } from '../service/token.service';
import { AdminauthService } from '../service/adminauth.service';

@Component({
  selector: 'app-adminlogin',
  templateUrl: './adminlogin.component.html',
  styleUrls: ['./adminlogin.component.css']
})
export class AdminloginComponent implements OnInit {
  errorMessage: string;
   loginForm: FormGroup;
  constructor(
    private service: AdminauthService,
    private fb: FormBuilder,
    private router : Router,
    private tokenService: TokenService
  ) { }

  ngOnInit() {
    this.init();
  }
  init() {
    this.loginForm = this.fb.group({
      email: ["", [Validators.required, Validators.email]],
      password: ["", Validators.required]
    })
  };
  get email() {
    return this.loginForm.get('email');
  }
  get password() {
    return this.loginForm.get('password');
  }
  
  onClick() {
    this.router.navigate(['/flightupde'])
  }
  login() {
    this.service.loginUser(this.loginForm.value).subscribe(user=> {

      this.tokenService.SetToken(user.token);
      this.loginForm.reset();

      this.router.navigate(['/contactus']);
    }, (err)=> {
      if(err.error.msg) {
        this.errorMessage = err.error.msg[0].message;
      }
      if(err.error.message) {
        this.errorMessage = err.error.message;
      }
      
    })

  }

}
