import { UpdateUser } from './../service/updateUsers.model';
import { AuthService } from './../service/auth.service';
import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-update-register',
  templateUrl: './update-register.component.html',
  styleUrls: ['./update-register.component.css'],
  providers: [AuthService]
})
export class UpdateRegisterComponent implements OnInit {
UpdateUser : any;
token : any ;
constructor( private update: AuthService ) {
  
}


getData(){
 //  this.update.getUser().toPromise().then(data =>{
 //    console.log(data);
 //    this.UpdateUser = data;
 //  })

 window.fetch(`http://localhost:3000/airlines`).then(data =>{
   data.json().then(res =>{
     console.log(res)
     this.UpdateUser = res;
   }).catch(err => console.log(err))
 })
}

ngOnInit() {
 this.resetForm();
 this.refreshUserList();
 this.getData();

}
resetForm(form? : NgForm) {
 if(form) {
   form.reset();
   this.update.updatemodel = {
     _id : "",
     username: "",
     email: "",
     phonenumber: ""
   
     

   } 
 }

}

onSubmit (form: NgForm) {
 this.update.registerUser(form.value).subscribe((res) => {
   this.resetForm(form);
     this.refreshUserList();
  })

}

// onSubmit(form : NgForm) {
//   if (form.value._id == "") {
//     this.update.registerUser(form.value).subscribe((res) => {
//       this.resetForm(form);
//       this.refreshUserList();
//       alert({ html: 'Saved successfully', classes: 'rounded' });
//     });
//   }
//   else {
//     this.update.editUser(form.value).subscribe((res) => {
//       this.resetForm(form);
//       this.refreshUserList();
//       alert({ html: 'Updated successfully', classes: 'rounded' });
//     });
//   }
// }

refreshUserList() {
 this.update.getUser().subscribe((res) => {
   this.update.usermodels = res as UpdateUser[];
 });
}

onEdit(airline: UpdateUser) {
 console.log(airline)
 this.update.updatemodel = airline;
}

onDelete(_id: string, form: NgForm) {
 if (confirm('Are you sure to delete this record ?') == true) {
   this.update.deleteUser(_id).subscribe((res) => {
     this.refreshUserList();
     this.resetForm(form);
     alert({ html: 'Deleted successfully', classes: 'rounded' });
   });
 }
}


}




  

