import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AirContactUsComponent } from './air-contact-us.component';

describe('AirContactUsComponent', () => {
  let component: AirContactUsComponent;
  let fixture: ComponentFixture<AirContactUsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AirContactUsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AirContactUsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
