import { Component, OnInit } from '@angular/core';
import { FormGroup, Validators, FormControl, FormBuilder } from '@angular/forms';
import { AdminauthService } from '../service/adminauth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-air-contact-us',
  templateUrl: './air-contact-us.component.html',
  styleUrls: ['./air-contact-us.component.css']
})
export class AirContactUsComponent implements OnInit {

  errorMessage: string;
  contactform: FormGroup;
 

  constructor(
    private service: AdminauthService,
    private fb: FormBuilder,
    private router: Router
  ) { }

  ngOnInit() {
  }
  get name() {
    return this.contactform.get('username');
  }
  get email() {
    return this.contactform.get('email');
  }
 
  get subject() {
    return this.contactform.get('subject');
  }
  get phonenumber() {
    return this.contactform.get('phonenumber');
  }
 
  get message() {
    return this.contactform.get('message');
  }

  
  init() {
    this.contactform = this.fb.group({
      name: ["", Validators.required],
      email: ["", Validators.required],
      subject: ["", Validators.required],
      phonenumber: ["", Validators.required],
      message: ["", Validators.required],

    })
}


  onSubmit() {
    this.service.contactUser(this.contactform.value).subscribe( user=> {
      this.contactform.reset();
      this.router.navigate(['/contactus']);
    })
  }
}
