import { TokenService } from './../service/token.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Component, OnInit } from '@angular/core';
import { AuthService } from '../service/auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-air-login',
  templateUrl: './air-login.component.html',
  styleUrls: ['./air-login.component.css']
})
export class AirLoginComponent implements OnInit {
   errorMessage: string;
   loginForm: FormGroup;
  constructor(
    private service: AuthService,
    private fb: FormBuilder,
    private router : Router,
    private tokenService: TokenService
  ) { }

  ngOnInit() {
    this.init()
  }
   
  init() {
    this.loginForm = this.fb.group({
      email: ["", [Validators.required, Validators.email]],
      password: ["", Validators.required]
    })
  };
  get email() {
    return this.loginForm.get('email');
  }
  get password() {
    return this.loginForm.get('password');
  }

  onRegister() {
    this.router.navigate(['/login'])
  }
  login() {
    this.service.loginUser(this.loginForm.value).subscribe(user=> {

      this.tokenService.SetToken(user.token);
      this.loginForm.reset();

      this.router.navigate(['/booking']);
    }, (err)=> {
      if(err.error.msg) {
        this.errorMessage = err.error.msg[0].message;
      }
      if(err.error.message) {
        this.errorMessage = err.error.message;
      }
      
    })
  }

}
