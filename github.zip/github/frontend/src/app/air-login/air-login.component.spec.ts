import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AirLoginComponent } from './air-login.component';

describe('AirLoginComponent', () => {
  let component: AirLoginComponent;
  let fixture: ComponentFixture<AirLoginComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AirLoginComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AirLoginComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
