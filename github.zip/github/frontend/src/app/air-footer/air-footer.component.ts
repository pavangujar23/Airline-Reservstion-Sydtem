import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-air-footer',
  templateUrl: './air-footer.component.html',
  styleUrls: ['./air-footer.component.css']
})
export class AirFooterComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
