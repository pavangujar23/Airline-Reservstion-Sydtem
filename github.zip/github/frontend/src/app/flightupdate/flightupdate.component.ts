import { FlightUpdateDetails } from './../shared/flightupdate.model';
import { Component, OnInit } from '@angular/core';
import { UpdateflightserviceService } from '../shared/updateflightservice.service';
import { NgForm } from '@angular/forms';

declare var M: any;
@Component({
  selector: 'app-flightupdate',
  templateUrl: './flightupdate.component.html',
  styleUrls: ['./flightupdate.component.css'],
  providers: [UpdateflightserviceService]
})



export class FlightupdateComponent implements OnInit {
  

  constructor(private flightservice: UpdateflightserviceService) { }

  ngOnInit() {
    this.resetForm();
    this.refreshFlightDetails();
  }

  resetForm(form?: NgForm) {
    if (form)
      form.reset();
    this.flightservice.selectedFlights = {
      _id: "",
      flightimg : "",
      flightname:  "",
      from: "",
      to: "",
      departuredate: "",
      status: ""
    }
  }

  onSubmit(form: NgForm) {
    if (form.value._id == "") {
      this.flightservice.postFlightDetails(form.value).subscribe((res) => {
        this.resetForm(form);
        this.refreshFlightDetails();
        alert({ html: 'Saved successfully', classes: 'rounded' });
      });
    }
    else {
      this.flightservice.putFlightDetails(form.value).subscribe((res) => {
        this.resetForm(form);
        this.refreshFlightDetails();
        alert({ html: 'Updated successfully', classes: 'rounded' });
      });
    }
  }

  refreshFlightDetails() {
    this.flightservice.getFlightDetails().subscribe((res) => {
      this.flightservice.flights = res as FlightUpdateDetails[];
    });
  }

  onEdit(flt: FlightUpdateDetails) {
    this.flightservice.selectedFlights = flt;
  }

  onDelete(_id: string, form: NgForm) {
    if (confirm('Are you sure to delete this record ?') == true) {
      this.flightservice.deleteFlightDetails(_id).subscribe((res) => {
        this.refreshFlightDetails();
        this.resetForm(form);
        alert({ html: 'Deleted successfully', classes: 'rounded' });
      });
    }
  }

}
