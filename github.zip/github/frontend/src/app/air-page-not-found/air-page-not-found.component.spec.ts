import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AirPageNotFoundComponent } from './air-page-not-found.component';

describe('AirPageNotFoundComponent', () => {
  let component: AirPageNotFoundComponent;
  let fixture: ComponentFixture<AirPageNotFoundComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AirPageNotFoundComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AirPageNotFoundComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
