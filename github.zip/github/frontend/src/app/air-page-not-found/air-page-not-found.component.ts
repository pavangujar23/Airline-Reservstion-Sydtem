import { Component, OnInit } from '@angular/core';



@Component({
  selector: 'app-air-page-not-found',
  templateUrl: './air-page-not-found.component.html',
  styleUrls: ['./air-page-not-found.component.css']
})
export class AirPageNotFoundComponent implements OnInit {

  constructor() { }

  ngOnInit() {


    
  }

}
