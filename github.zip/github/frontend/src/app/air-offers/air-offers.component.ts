import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-air-offers',
  templateUrl: './air-offers.component.html',
  styleUrls: ['./air-offers.component.css']
})
export class AirOffersComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
