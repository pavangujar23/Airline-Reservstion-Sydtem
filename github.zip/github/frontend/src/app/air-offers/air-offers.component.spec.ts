import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AirOffersComponent } from './air-offers.component';

describe('AirOffersComponent', () => {
  let component: AirOffersComponent;
  let fixture: ComponentFixture<AirOffersComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AirOffersComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AirOffersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
