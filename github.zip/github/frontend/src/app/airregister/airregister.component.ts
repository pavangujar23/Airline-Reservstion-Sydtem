import { AuthService } from './../service/auth.service';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, Validators, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-airregister',
  templateUrl: './airregister.component.html',
  styleUrls: ['./airregister.component.css']
})
export class AirregisterComponent implements OnInit {
  errorMessage: string;
  registerForm: FormGroup;
  constructor(
    private service: AuthService,
    private fb: FormBuilder,
    private router: Router
  ) { }

  ngOnInit() {
    this.init();
  }


  get username() {
    return this.registerForm.get('username');
  }
  get email() {
    return this.registerForm.get('email');
  }
  get phonenumber() {
    return this.registerForm.get('phonenumber');
  }
  get password() {
    return this.registerForm.get('password');
  }

  init() {
    this.registerForm = this.fb.group({
      username: ["", Validators.required],
      email: ["", [Validators.required, Validators.email]],
      phonenumber: ["", Validators.required],
      password: ["", Validators.required]
    });
  }

  onClick() {
    this.router.navigate(['/login']);
  }

  onSubmit() {
    this.service.registerUser(this.registerForm.value).subscribe( user=> {
      this.registerForm.reset();
      this.router.navigate(['/login']);
    },
   (err)=> {
    if (err.error.msg) {
      this.errorMessage = err.error.msg[0].message;

    }
    if(err.error.message) {
      this.errorMessage = err.error.message;    
    }
  })

};

}