import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AirregisterComponent } from './airregister.component';

describe('AirregisterComponent', () => {
  let component: AirregisterComponent;
  let fixture: ComponentFixture<AirregisterComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AirregisterComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AirregisterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
