import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-airsafety',
  templateUrl: './airsafety.component.html',
  styleUrls: ['./airsafety.component.css']
})
export class AirsafetyComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
