import { BookingComponent } from './booking/booking.component';
import { FlightupdateComponent } from './flightupdate/flightupdate.component';
import { AirsafetyComponent } from './airsafety/airsafety.component';
import { AdminregisterComponent } from './adminregister/adminregister.component';
import { AdminloginComponent } from './adminlogin/adminlogin.component';
import { AirPageNotFoundComponent } from './air-page-not-found/air-page-not-found.component';
import { AirOffersComponent } from './air-offers/air-offers.component';
import { AirContactUsComponent } from './air-contact-us/air-contact-us.component';
import { AirAboutUsComponent } from './air-about-us/air-about-us.component';

import { AirHeaderComponent } from './air-header/air-header.component';
import { AirHomeComponent } from './air-home/air-home.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AirLoginComponent } from './air-login/air-login.component';
import { AirregisterComponent } from './airregister/airregister.component';
import { AuthGuard } from './service/authentication-guard.guard';
import { UpdateRegisterComponent } from './update-register/update-register.component';

const routes: Routes = [
  {path : '' , component : AirHomeComponent},
  {path : 'safety' , component : AirsafetyComponent, canActivate : [AuthGuard]} ,
  {path : 'booking' , component : BookingComponent, canActivate : [AuthGuard]} ,
  {path : 'flightupdate' , component : FlightupdateComponent, canActivate : [AuthGuard]} ,
  {path : 'header' , component : AirHeaderComponent, canActivate : [AuthGuard]} ,
  {path : 'login' , component : AirLoginComponent, } ,
  {path : 'updateuser' , component : UpdateRegisterComponent, canActivate : [AuthGuard]} ,
  {path : 'register', component: AirregisterComponent},
  {path : 'adminlogin' , component : AdminloginComponent, canActivate : [AuthGuard]} ,
  {path : 'adminregister', component: AdminregisterComponent, canActivate : [AuthGuard]},
  {path : 'aboutus' , component : AirAboutUsComponent } ,
  {path : 'contactus' , component : AirContactUsComponent, canActivate : [AuthGuard]  } ,
  {path : 'offers' , component : AirOffersComponent, canActivate : [AuthGuard]} , 
  {path : '**' , component : AirPageNotFoundComponent} ,
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
