import { from } from 'rxjs';
import { BookingService } from './../service/booking.service';
import { AuthService } from './../service/auth.service';
import { Component, OnInit } from '@angular/core';
import * as $ from 'jquery';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
@Component({
  selector: 'app-air-home',
  templateUrl: './air-home.component.html',
  styleUrls: ['./air-home.component.css']
})
export class AirHomeComponent implements OnInit {

  errorMessage: String;
  bookingForm: FormGroup;
  constructor(
    private service: AuthService,
    private fb: FormBuilder,
    private router: Router
  ) { }

  ngOnInit() {
    this.init();
  }

  get from() {
    return this.bookingForm.get('from');
  }
  get to() {
    return this.bookingForm.get('to');
  }
 
  get arrival() {
    return this.bookingForm.get('arrival');
  }
  get departure() {
    return this.bookingForm.get('departure');
  }
 
  get class() {
    return this.bookingForm.get('class');
  }
  get adult() {
    return this.bookingForm.get('adult');
  }
  init() {
    this.bookingForm = this.fb.group({
      from: ["", Validators.required],
      to: ["", Validators.required],
      arrival: ["", Validators.required],
      departure: ["", Validators.required],
      class: ["", Validators.required],
      adult: ["", Validators.required]
    });
  }

  onClick() {
    this.router.navigate(['./login']);
  }
 
  onSubmit() {
    this.service.bookingUser(this.bookingForm.value).subscribe( user=> {
      this.bookingForm.reset();
      this.router.navigate(['/register']);
    },
   (err)=> {
    if (err.error.msg) {
      this.errorMessage = err.error.msg[0].message;

    }
    if(err.error.message) {
      this.errorMessage = err.error.message;    
    }
  })

};
   





}
